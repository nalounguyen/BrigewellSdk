//
//  ConfigurationKey.swift
//  BrigewellApp
//
//  Created by Nalou Nguyen on 16/01/2024.
//

import Foundation

enum ConfigurationKey {
    enum Url {
        public static let serverBaseUrl = "SERVER_BASE_URL"
    }
}
