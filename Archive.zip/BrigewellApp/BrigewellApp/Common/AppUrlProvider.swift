//
//  AppUrlProvider.swift
//  BrigewellApp
//
//  Created by Nalou Nguyen on 16/01/2024.
//

import Foundation

public protocol UrlProvider {
    var serverBaseUrl: String? { get }
}
