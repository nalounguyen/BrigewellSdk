//
//  NetworkAssembly.swift
//  BrigewellApp
//
//  Created by Nalou Nguyen on 09/01/2024.
//

import Foundation
import Swinject
import BrigewellSdk

final class NetworkAssembly: Assembly {
    func assemble(container: Container) {
        container
            .register(AppConfiguration.self) { _ -> AppConfiguration in
                return AppConfiguration(bundle: Bundle.main)
            }
            .inObjectScope(.container)

        container
            .register(UrlProvider.self) { resolver -> UrlProvider in
                guard let urlProvider = resolver.resolve(AppConfiguration.self)
                else { fatalError("Can not resolve \(AppConfiguration.self)") }
                return urlProvider
            }
            .inObjectScope(.container)

        container
            .register(NetworkClient.self) { resolver -> NetworkClient in
                guard let appConfiguration = resolver.resolve(UrlProvider.self),
                      let baseUrl = appConfiguration.serverBaseUrl
                else {
                    fatalError("baseUrl is not provided") }

                guard let networkClient = NetworkClientImplementation(endPoint: baseUrl) else {
                    fatalError("Initialize NetworkClient failure")
                }
                return networkClient
            }
            .inObjectScope(.container)
    }
}
