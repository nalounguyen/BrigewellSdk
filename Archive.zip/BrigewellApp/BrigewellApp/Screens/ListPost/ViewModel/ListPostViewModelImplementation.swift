//
//  ListPostViewModelImplementation.swift
//  BrigewellApp
//
//  Created by Nalou Nguyen on 09/01/2024.
//

import Foundation
import RxSwift
import RxCocoa
import BrigewellSdk

final class ListPostViewModelImplementation {
    private var getPostsUseCase: GetPostsUseCase

    private let onGetAllPostSubject = PublishSubject<Void>()
    private let onStartGetAllPostSubject = PublishSubject<[PostModel]>()
    private var disposeBag = DisposeBag()

    init(getPostsUseCase: GetPostsUseCase) {
        self.getPostsUseCase = getPostsUseCase
        binding()
    }

    private func binding() {
        onGetAllPostSubject
            .subscribe { [weak self] _ in
                guard let self =  self else { return }
                self.getPostsUseCase
                    .execute()
                    .bind(to: self.onStartGetAllPostSubject)
                    .disposed(by: self.disposeBag)
            }
            .disposed(by: disposeBag)
    }

}


// MARK: ListPostStreamFlow
extension ListPostViewModelImplementation: ListPostViewModel {
    var input: ListPostInput {
        return self
    }

    var output: ListPostOutput {
        return self
    }
}

// MARK: ListPostInput
extension ListPostViewModelImplementation: ListPostInput {
    var onGetAllPost: AnyObserver<Void> {
        return onGetAllPostSubject
            .asObserver()
    }
}

// MARK: ListPostOutput
extension ListPostViewModelImplementation: ListPostOutput {
    var onStartGetAllPost: Driver<[PostModel]> {
        return onStartGetAllPostSubject
            .asDriver(onErrorDriveWith: .never())
    }
}
