//
//  GetCommentsUseCaseTest.swift
//  BrigewellSdkTests
//
//  Created by Nalou Nguyen on 16/01/2024.
//

@testable import BrigewellSdk
import RxCocoa
import RxSwift
import RxTest
import XCTest

class GetCommentsUseCaseTest: XCTestCase {
    private let disposeBag = DisposeBag()
    
    private var testScheduler: TestScheduler!
    private var repository = PostRepositoryMock()
    private var useCase: GetCommentsUseCase!
    
    override func setUp() {
        testScheduler = TestScheduler(initialClock: 0)
        useCase = GetCommentsUseCaseImplementation(postRepository: repository)
    }
    
    func testExecuteUseCase() {
        repository.stubbedGetCommentById = Observable.just(MockData.getCommentByIds)
        let result = testScheduler.createObserver([CommentModel].self)
        
        testScheduler.scheduleAt(1) { [unowned self] in
            self.useCase
                .execute(listPostId: [1])
                .bind(to: result)
                .disposed(by: disposeBag)
        }
        
        testScheduler.start()
        
        XCTAssertEqual(repository.invokeGetCommentByIdCount, 1)
        XCTAssertEqual(result.events[0].value.element, MockData.getCommentByIds)
    }
    
    func testExecuteUseCaseEmpty() {
        repository.stubbedGetCommentById = Observable.just(MockData.getCommentByIds)
        let result = testScheduler.createObserver([CommentModel].self)
        
        testScheduler.scheduleAt(1) { [unowned self] in
            useCase.execute(listPostId: []).bind(to: result).disposed(by: disposeBag)
        }
        
        testScheduler.start()
        
        XCTAssertEqual(result.events[0].value.element, [])
    }
}
