//
//  PostRepositoryTest.swift
//  BrigewellSdkTests
//
//  Created by Nalou Nguyen on 16/01/2024.
//

import XCTest
import RxSwift
import RxCocoa
import RxTest

@testable import BrigewellSdk

class PostRepositoryTest: XCTestCase {
    private let disposeBag = DisposeBag()
    
    private var testScheduler: TestScheduler!
    private var networking: NetworkMock!
    private var repository: PostRepository!
    
    override func setUp() {
        testScheduler = TestScheduler(initialClock: 0)
        networking = NetworkMock()
        repository = PostRepositoryImplementation(networking: networking)
    }
}

extension PostRepositoryTest {
    func testGetAllPost() throws {
        let onResult = testScheduler.createObserver([PostModel].self)
        let mockGetAllPostResponse = MockData.getAllPostResponse
        
        networking.stubbedExecuteRequestResult = Observable.just(mockGetAllPostResponse)
        
        repository
            .getAllPost()
            .subscribe (onNext: { result in
                onResult.onNext(result)
            })
            .disposed(by: disposeBag)
        
        let resultElements = onResult.events.first?.value.element ?? []
        let expectedResponse = MockData.getAllPostResponse
        
        XCTAssertEqual(onResult.events.count, 1)
        XCTAssertEqual(resultElements, expectedResponse)
    }
    
    func testGetCommentByIds() throws {
        let onResult = testScheduler.createObserver([CommentModel].self)
        let mockGetCommentByIdsResponse = MockData.getCommentByIds
        
        networking.stubbedExecuteRequestResult = Observable.just(mockGetCommentByIdsResponse)
        
        repository
            .getCommentBy(postId: [1])
            .subscribe (onNext: { result in
                onResult.onNext(result)
            })
            .disposed(by: disposeBag)
        
        let resultElements = onResult.events.first?.value.element ?? []
        let expectedResponse = MockData.getCommentByIds
        
        XCTAssertEqual(onResult.events.count, 1)
        XCTAssertEqual(resultElements, expectedResponse)
    }
}
