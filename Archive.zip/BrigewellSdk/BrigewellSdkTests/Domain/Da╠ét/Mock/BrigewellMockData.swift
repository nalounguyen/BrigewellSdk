//
//  BrigewellMockData.swift
//  BrigewellSdkTests
//
//  Created by Nalou Nguyen on 16/01/2024.
//

@testable import BrigewellSdk

typealias MockData = BrigewellMockData

enum BrigewellMockData {
    
    // MARK: Responses
    static let getAllPostResponse = [PostModel(userId: 1, id: 1, title: "title 1", body: "body 1"),
                                     PostModel(userId: 1, id: 2, title: "title 2", body: "body 2"),
                                     PostModel(userId: 1, id: 3, title: "title 3", body: "body 3"),
                                     PostModel(userId: 1, id: 4, title: "title 4", body: "body 4")
                                    ]
    
    static let getCommentByIds = [CommentModel(postId: 1, id: 1, name: "name 1", email: "email 1", body: "body 1"),
                                  CommentModel(postId: 1, id: 2, name: "name 2", email: "email 2", body: "body 2"),
                                  CommentModel(postId: 1, id: 3, name: "name 3", email: "email 3", body: "body 3"),
                                  CommentModel(postId: 1, id: 4, name: "name 4", email: "email 4", body: "body 4")
                                 ]
}
