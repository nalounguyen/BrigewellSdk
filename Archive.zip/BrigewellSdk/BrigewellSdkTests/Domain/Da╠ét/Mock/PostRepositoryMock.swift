//
//  PostRepositoryMock.swift
//  BrigewellSdkTests
//
//  Created by Nalou Nguyen on 16/01/2024.
//

@testable import BrigewellSdk
import RxSwift

class PostRepositoryMock: PostRepository {
    
    var invokeGetAllPost = false
    var invokeGetAllPostCount = 0
    var stubbedGetAllPost: Observable<[PostModel]>!
    func getAllPost() -> Observable<[PostModel]> {
        invokeGetAllPost = true
        invokeGetAllPostCount += 1
        return stubbedGetAllPost
    }
    
    
    var invokeGetCommentById = false
    var invokeGetCommentByIdCount = 0
    var stubbedGetCommentById: Observable<[CommentModel]>!
    func getCommentBy(postId: [Int]) -> Observable<[CommentModel]> {
        invokeGetCommentById = true
        invokeGetCommentByIdCount += 1
        return stubbedGetCommentById
    }
    
    
}
