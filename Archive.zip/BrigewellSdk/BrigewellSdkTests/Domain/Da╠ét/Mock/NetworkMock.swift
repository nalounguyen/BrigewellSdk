//
//  NetworkMock.swift
//  BrigewellSdkTests
//
//  Created by Nalou Nguyen on 16/01/2024.
//

import Foundation
import RxSwift

@testable import BrigewellSdk

class NetworkMock: NetworkClient {
    
    // MARK: GET
    
    var invokeExecuteRequest = false
    var invokeExecuteRequestCount = 0
    var stubbedExecuteRequestResult: Observable<Any>?
    
    func executeRequest<T>(_ apiRequest: BrigewellSdk.ApiRequest) -> RxSwift.Observable<T> where T : Decodable, T : Encodable {
        invokeExecuteRequest = true
        invokeExecuteRequestCount += 1
        
        return stubbedExecuteRequestResult?.compactMap({ $0 as? T }) ?? Observable.empty()
    }
}
