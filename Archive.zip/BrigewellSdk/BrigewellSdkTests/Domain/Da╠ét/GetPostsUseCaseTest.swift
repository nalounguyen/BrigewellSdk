//
//  GetPostsUseCaseTest.swift
//  BrigewellSdkTests
//
//  Created by Nalou Nguyen on 16/01/2024.
//

@testable import BrigewellSdk
import RxCocoa
import RxSwift
import RxTest
import XCTest

class GetPostsUseCaseTest: XCTestCase {
    private let disposeBag = DisposeBag()
    
    private var testScheduler: TestScheduler!
    private var repository = PostRepositoryMock()
    private var useCase: GetPostsUseCase!
    
    override func setUp() {
        testScheduler = TestScheduler(initialClock: 0)
        useCase = GetPostsUseCaseImplementation(postRepository: repository)
    }
    
    func testExecuteUseCase() {
        repository.stubbedGetAllPost = Observable.just(MockData.getAllPostResponse)
        let result = testScheduler.createObserver([PostModel].self)
        
        _ = useCase.execute()
        
        testScheduler.scheduleAt(1) { [unowned self] in
            self.repository
                .getAllPost()
                .bind(to: result)
                .disposed(by: disposeBag)
        }
        
        testScheduler.start()
        
        XCTAssertEqual(repository.invokeGetAllPostCount, 2)
        XCTAssertEqual(result.events[0].value.element, MockData.getAllPostResponse)
    }
}
