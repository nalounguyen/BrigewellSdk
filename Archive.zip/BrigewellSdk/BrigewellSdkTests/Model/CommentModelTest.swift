//
//  CommentModelTest.swift
//  BrigewellSdkTests
//
//  Created by Nalou Nguyen on 16/01/2024.
//

import XCTest
import RxSwift
import RxCocoa
import RxTest

@testable import BrigewellSdk


class CommentModelTest: XCTestCase {
    var modelOne: CommentModel!
    var modelTwo: CommentModel!
    
    
    func testCompare() throws {
        modelOne = CommentModel(postId: 1, id: 1, name: "name 1", email: "email 1", body: "body 1")
        modelTwo = CommentModel(postId: 1, id: 2, name: "name 2", email: "email 2", body: "body 1")
        XCTAssertNotEqual(modelOne, modelTwo)
        
        modelOne = CommentModel(postId: 1, id: 1, name: "name 1", email: "email 1", body: "body 1")
        modelTwo = CommentModel(postId: 1, id: 1, name: "name 1", email: "email 1", body: "body 1")
        XCTAssertEqual(modelOne, modelTwo)
    }
}
