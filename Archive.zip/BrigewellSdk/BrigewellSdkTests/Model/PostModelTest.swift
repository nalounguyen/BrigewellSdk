//
//  PostModelTest.swift
//  BrigewellSdkTests
//
//  Created by Nalou Nguyen on 16/01/2024.
//

import XCTest
import RxSwift
import RxCocoa
import RxTest

@testable import BrigewellSdk


class PostModelTest: XCTestCase {
    var modelOne: PostModel!
    var modelTwo: PostModel!
    
    
    func testCompare() throws {
        modelOne = PostModel(userId: 1, id: 1, title: "title 1", body: "body 1")
        modelTwo = PostModel(userId: 2, id: 2, title: "title 2", body: "body 2")
        XCTAssertNotEqual(modelOne, modelTwo)
        
        modelOne = PostModel(userId: 1, id: 1, title: "title 1", body: "body 1")
        modelTwo = PostModel(userId: 1, id: 1, title: "title 1", body: "body 1")
        XCTAssertEqual(modelOne, modelTwo)
    }
}
