//
//  PostModel.swift
//  BrigewellSdk
//
//  Created by Nalou Nguyen on 09/01/2024.
//

import Foundation

public struct PostModel: Codable {
    public var userId: Int
    public var id: Int
    public var title: String
    public var body: String
    public var comments: [CommentModel]?
}

extension PostModel: Equatable {
    public static func == (lhs: PostModel, rhs: PostModel) -> Bool {
        return lhs.userId == rhs.userId
        && lhs.id == rhs.id
        && lhs.title == rhs.title
        && lhs.body == rhs.body
        && lhs.comments == rhs.comments
    }
}
