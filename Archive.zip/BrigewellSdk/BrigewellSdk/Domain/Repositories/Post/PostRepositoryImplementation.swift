//
//  PostRepositoryImplementation.swift
//  BrigewellSdk
//
//  Created by Nalou Nguyen on 09/01/2024.
//

import Foundation
import RxSwift

public class PostRepositoryImplementation: BaseRepositoryImplementation , PostRepository {
    public func getAllPost() -> Observable<[PostModel]> {
        let request = GetPostsRequest()
        return networking.executeRequest(request)
    }
}
