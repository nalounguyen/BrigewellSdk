//
//  BaseUseCase.swift
//  FootballApp
//
//  Created by Nalou Nguyen on 07/01/2024.
//

import Foundation
import Combine

protocol BaseUseCase { }
